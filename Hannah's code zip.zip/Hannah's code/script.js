function send() {
    let firstName = document.getElementById("fname").value;
    let lastName = document.getElementById("lname").value;

    alert(`Thank you, ${firstName} for submitting your response. We will get back to you as soon as possible!`);
}